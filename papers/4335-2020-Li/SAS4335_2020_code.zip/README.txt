1) Copy the datastes in the zip file to your SASUSER.
2) Copy the image silvercoin_darker in the zip file to a directory somewhere.
3) Run tilegridmap_setup.sas first before running any other example program.
4) The main example in the paper is us_ppopulation_growth.sas.
5) The other examples are also in the zip file.
6) For us_income.sas, you need to modify the symbolimage in the code to specify the correct path of the silvercoin_darker.png.
7) For china_gdp_sgpanel.sas, you need to run SAS in a Chinese session with -lang zh.
